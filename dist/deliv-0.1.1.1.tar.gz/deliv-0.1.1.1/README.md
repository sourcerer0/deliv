# deliv
Delivery service scraper

## Installation
Get source code
```shell script
git clone git@github.com:sourcerer0/deliv.git && cd deliv

sudo python3 -m setup install
```
> Don't forget to add --branch to 'git clone' command, and get the latest version.

### Dependancies
#### Package Installer
```shell script
pip3 install -r requirements.txt
```

## Docs

## Contributing & Issue Tracker
Branch & [Pull Request](https://github.com/sourcerer0/deliv/pulls)
- [Issues](https://github.com/sourcerer0/deliv/issues)

## License
[Apache License 2.0](https://github.com/sourcerer0/deliv/blob/master/LICENSE)
